<?php

global $page;

include($page->theme_dir . '/' . $page->theme_color . '/template.php');