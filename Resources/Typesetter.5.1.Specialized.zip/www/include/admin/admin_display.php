<?php
defined('is_running') or die('Not an entry point...');

/**
 * @deprecated
 * Used by FrontEndUser and Ajax Pages
 */
class admin_display extends \gp\admin{}
