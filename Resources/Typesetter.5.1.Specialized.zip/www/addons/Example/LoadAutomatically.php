<?php

namespace Addon\Example;

class LoadAutomatically{

	function AutomaticallyLoaded(){
		echo '<h3>Autoload</h3>';
		echo '<p>This portion was loaded automatically</p>';
	}

}